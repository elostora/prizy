# ListSearcher
<img src="https://raw.githubusercontent.com/tegal1337/ListSearcher/main/Searcher-tegalsec.jpg">

Stable with Python 2.7.18<br> [Download Here](https://www.python.org/downloads/release/python-2718/)<br><br>
**Module Requirements:**<br>
~ requests<br>
~ socket<br>
~ json<br>
~ multiprocessing<br>
~ colorama<br>

#### Even tough it's open source. Please don't change the Author and don't delete the Copyright!

*Contributor:*<br>
1. Ali Akbar [ [Github](https://github.com/LoliC0d3) ]
2. Hasyim    [ [Github](https://github.com/xcapri) ]
3. Faiz      [ [Github](https://github.com/faizgans14) ]
4. Azhari    [ [Github](https://github.com/AzhariKun) ]
